<?php
echo '<?xml version="1.0" encoding="utf-8"?>';
?>
<urlset
      xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
            http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">


<url>
  <loc>https://onlinetireshop.ae/</loc>
  <lastmod>2024-01-04T20:27:04+00:00</lastmod>
  <priority>1.00</priority>
</url>
<url>
  <loc>https://onlinetireshop.ae/about</loc>
  <lastmod>2024-01-04T20:27:04+00:00</lastmod>
  <priority>0.80</priority>
</url>
<url>
  <loc>https://onlinetireshop.ae/services</loc>
  <lastmod>2024-01-04T20:27:04+00:00</lastmod>
  <priority>0.80</priority>
</url>
<url>
  <loc>https://onlinetireshop.ae/contact</loc>
  <lastmod>2024-01-04T20:27:04+00:00</lastmod>
  <priority>0.80</priority>
</url>


</urlset>
